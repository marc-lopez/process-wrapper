import nose

nose.run()